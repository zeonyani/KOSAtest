typedef struct div {
	int quo;
	int remai;
} Div;