double TriangleArea(double base, double height);
double CircleArea(double rad);
